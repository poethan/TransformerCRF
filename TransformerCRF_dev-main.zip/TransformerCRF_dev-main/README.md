### Current Available Functions

- TransformerCRF word-level model: train model from scratch
- BioformerCRF: using pre-trained Bioformer with CRF layer for fine-tuning
- ClinicalBERT-CRF: using pre-trained ClinicalBERT with CRF layer for fine-tuning
- BioformerApt: Using pre-trained parameters from Bioformer with an adaptation layer for text mining task

### Requirements

- Python 3.7.13
- Tensorflow 1.14.0  / 2.9.1 (using 2.9.1)
- tensorflow-addons 0.17.0 # if use tf2
- transformers 4.20.1
- matplotlib
- sklearn
- spacy
- pytorch

## Running the trained model on n2c2 dataset

1. add the .txt files in  data -> x-test ->deploy
2. make sure you are using python 3
3. run main.py that is located in src

```
python main.py --parameters_filepath 'parameters.ini'
```

4. check the output in output -> brat -> deploy

## Acknowledgement on used packages
- [NeuroNER](https://github.com/Franck-Dernoncourt/NeuroNER)
- [Transformers](https://huggingface.co/docs/transformers/index)
- conll2003 eval shared task
- [stanford coreNLP](https://stanfordnlp.github.io/CoreNLP/)
- Bioformer and ClinicalBERT
