import time, re, os, pickle, random, glob
import collections, codecs, token
import sklearn.preprocessing
import numpy as np
from transformers import AutoTokenizer

import utils_nlp
import utils
import conll_to_brat
import brat_to_conll

class Dataset(object):
    """A class for handling data sets."""

    def __init__(self, parameters, verbose=False):
        self.parameters = parameters
        self.verbose = verbose

        # pre-setting
        self.UNK_TOKEN_INDEX = 1 # for batch_size, 0 is resevred for [PAD]
        self.PADDING_CHARACTER_INDEX = 0
        self.UNK = 'UNK'
        self.map2unk_threshold = 1
        self.tokenizer = None

        # to be filled when loading dataset
        self.dataset_filepaths = None
        self.dataset_brat_folders = None
        self.token_to_vector = None
        self.embedding_matrix = None

        self.index_to_token = None
        self.token_to_index = None
        self.index_to_character = None
        self.character_to_index = None
        self.index_to_label = None
        self.label_to_index = None
        self.unique_labels = []
        self.unique_labels_of_interest = None
        self.unique_label_indices_of_interest = []
        self.infrequent_token_indices = []
        self.tokens_mapped_to_unk = []

        self.tokens = None
        self.labels = None
        self.valid_tokens_index = None

        self.vocabulary_size = 0
        self.alphabet_size = 0
        self.number_of_classes = 0

        self.token_indices = None
        self.label_indices = None
        self.character_indices_padded = None
        self.character_indices = None
        self.token_lengths = None
        self.characters = None
        self.label_vector_indices = None


        self._get_valid_dataset_filepaths()

    def _get_valid_dataset_filepaths(self):
        '''
        To derive correct dataset filepaths and mapping/generating between bart and conll format (also bios)
        '''
        dataset_filepaths = {}
        dataset_brat_folders = {}
        for dataset_type in ['train', 'valid', 'test', 'deploy']:
            dataset_filepaths[dataset_type] = os.path.join(self.parameters['dataset_text_folder'], '{0}.txt'.format(dataset_type)) # train.txt
            dataset_brat_folders[dataset_type] = os.path.join(self.parameters['dataset_text_folder'], dataset_type) # train
            dataset_compatible_with_brat_filepath = os.path.join(self.parameters['dataset_text_folder'], '{0}_compatible_with_brat.txt'.format(dataset_type)) # train_compatible_with_brat.txt

            # Conll file exists
            if os.path.isfile(dataset_filepaths[dataset_type]) and os.path.getsize(dataset_filepaths[dataset_type]) > 0:
                # Brat text files exist
                if os.path.exists(dataset_brat_folders[dataset_type]) and len(glob.glob(os.path.join(dataset_brat_folders[dataset_type], '*.txt'))) > 0:

                    # Check compatibility between conll and brat files
                    brat_to_conll.check_brat_annotation_and_text_compatibility(dataset_brat_folders[dataset_type], parameters['split_discontinuous'])
                    if os.path.exists(dataset_compatible_with_brat_filepath):
                        dataset_filepaths[dataset_type] = dataset_compatible_with_brat_filepath
                    conll_to_brat.check_compatibility_between_conll_and_brat_text(dataset_filepaths[dataset_type], dataset_brat_folders[dataset_type])

                # Brat text files do not exist
                else:

                    # Populate brat text and annotation files based on conll file
                    conll_to_brat.conll_to_brat(dataset_filepaths[dataset_type], dataset_compatible_with_brat_filepath, dataset_brat_folders[dataset_type], dataset_brat_folders[dataset_type])
                    dataset_filepaths[dataset_type] = dataset_compatible_with_brat_filepath

            # Conll file does not exist
            else:
                # Brat text files exist
                if os.path.exists(dataset_brat_folders[dataset_type]) and len(glob.glob(os.path.join(dataset_brat_folders[dataset_type], '*.txt'))) > 0:
                    dataset_filepath_for_tokenizer = os.path.join(self.parameters['dataset_text_folder'], '{0}_{1}.txt'.format(dataset_type, self.parameters['tokenizer']))
                    if os.path.exists(dataset_filepath_for_tokenizer):
                        conll_to_brat.check_compatibility_between_conll_and_brat_text(dataset_filepath_for_tokenizer, dataset_brat_folders[dataset_type])
                    else:
                        # Populate conll file based on brat files
                        brat_to_conll.brat_to_conll(dataset_brat_folders[dataset_type],
                                dataset_filepath_for_tokenizer, self.parameters['tokenizer'], self.parameters['spacylanguage'], self.parameters['split_discontinuous'])
                    dataset_filepaths[dataset_type] = dataset_filepath_for_tokenizer

                # Brat text files do not exist
                else:
                    del dataset_filepaths[dataset_type]
                    del dataset_brat_folders[dataset_type]
                    continue

            if self.parameters['tagging_format'] == 'bioes':
                # Generate conll file with BIOES format
                bioes_filepath = os.path.join(self.parameters['dataset_text_folder'], '{0}_bioes.txt'.format(utils.get_basename_without_extension(dataset_filepaths[dataset_type])))
                utils_nlp.convert_conll_from_bio_to_bioes(dataset_filepaths[dataset_type], bioes_filepath)
                dataset_filepaths[dataset_type] = bioes_filepath

        self.dataset_filepaths = dataset_filepaths
        self.dataset_brat_folders = dataset_brat_folders

        return


    def _parse_dataset(self, dataset_filepath):
        '''
        Read tokens/labels in specific train/valid/test/deploy dataset
        and return their frequency table
        '''
        token_count = collections.defaultdict(lambda: 0)
        label_count = collections.defaultdict(lambda: 0)
        character_count = collections.defaultdict(lambda: 0)

        line_count = -1
        tokens = []
        labels = []
        new_token_sequence = []
        new_label_sequence = []
        if dataset_filepath:
            f = codecs.open(dataset_filepath, 'r', 'UTF-8')
            for line in f:
                line_count += 1
                line = line.strip().split(' ')
                if len(line) == 0 or len(line[0]) == 0 or '-DOCSTART-' in line[0]:
                    if len(new_token_sequence) > 0:
                        labels.append(new_label_sequence)
                        tokens.append(new_token_sequence)
                        new_token_sequence = []
                        new_label_sequence = []
                    continue
                token = str(line[0])
                label = str(line[-1])
                token_count[token] += 1
                label_count[label] += 1

                new_token_sequence.append(token)
                new_label_sequence.append(label)

                for character in token:
                    character_count[character] += 1

                # if self.debug and line_count > 200: break# for debugging purposes

            if len(new_token_sequence) > 0:
                labels.append(new_label_sequence)
                tokens.append(new_token_sequence)
            f.close()
        return labels, tokens, token_count, label_count, character_count


    def _convert_to_indices(self, dataset_types):
        tokens = self.tokens
        labels = self.labels
        token_to_index = self.token_to_index
        character_to_index = self.character_to_index
        label_to_index = self.label_to_index
        index_to_label = self.index_to_label

        # Map tokens and labels to their indices
        token_indices = {}
        label_indices = {}
        characters = {}
        token_lengths = {}
        character_indices = {}
        character_indices_padded = {}
        for dataset_type in dataset_types:
            token_indices[dataset_type] = []
            characters[dataset_type] = []
            character_indices[dataset_type] = []
            token_lengths[dataset_type] = []
            character_indices_padded[dataset_type] = []
            for token_sequence in tokens[dataset_type]:
                token_indices[dataset_type].append([token_to_index.get(token, self.UNK_TOKEN_INDEX) for token in token_sequence])
                characters[dataset_type].append([list(token) for token in token_sequence])
                character_indices[dataset_type].append([[character_to_index.get(character, random.randint(1, max(self.index_to_character.keys()))) for character in token] for token in token_sequence])
                token_lengths[dataset_type].append([len(token) for token in token_sequence])
                longest_token_length_in_sequence = max(token_lengths[dataset_type][-1])
                character_indices_padded[dataset_type].append([utils.pad_list(temp_token_indices, longest_token_length_in_sequence, self.PADDING_CHARACTER_INDEX) for temp_token_indices in character_indices[dataset_type][-1]])

            label_indices[dataset_type] = []
            for label_sequence in labels[dataset_type]:
                label_indices[dataset_type].append([label_to_index[label] for label in label_sequence])
        label_binarizer = sklearn.preprocessing.LabelBinarizer()
        label_binarizer.fit(range(max(index_to_label.keys()) + 1)) # for batch_size
        label_vector_indices = {}
        for dataset_type in dataset_types:
            label_vector_indices[dataset_type] = []
            for label_indices_sequence in label_indices[dataset_type]:
                label_vector_indices[dataset_type].append(label_binarizer.transform(label_indices_sequence))

        return token_indices, label_indices, character_indices_padded, character_indices, token_lengths, characters, label_vector_indices


    def load_pretrained_token_embeddings(self):
        if self.token_to_vector == None:
            raise ValueError('Loading pre-trained token embeddings fails and there is nothing in token_to_index.')
        else:
            print('Converting pre-trained token embeddings to embedding matrix...', end='', flush=True)

        embedding_matrix = np.zeros((self.vocabulary_size, self.parameters['token_embedding_dimension']))

        for token in self.token_to_index.keys():
            token_lower = token.lower()
            token_no_digits = re.sub(r'\d', '0', token)
            token_lower_no_digits = re.sub(r'\d', '0', token_lower)
            if token in self.token_to_vector.keys():
                embedding_matrix[self.token_to_index[token]] = self.token_to_vector[token]
            elif self.parameters['check_for_lowercase'] and token_lower in self.token_to_vector.keys():
                embedding_matrix[self.token_to_index[token]] = self.token_to_vector[token_lower]
            elif self.parameters['check_for_digits_replaced_with_zeros'] and token_no_digits in self.token_to_vector.keys():
                embedding_matrix[self.token_to_index[token]] = self.token_to_vector[token_no_digits]
            elif self.parameters['check_for_lowercase'] and self.parameters['check_for_digits_replaced_with_zeros'] and token_lower_no_digits in self.token_to_vector.keys():
                embedding_matrix[self.token_to_index[token]] = self.token_to_vector[token_lower_no_digits]
            else:
                continue
        print('Done.')

        return embedding_matrix


    def load_dataset_from_scratch(self):
        '''
        dataset_filepaths : dictionary with keys 'train', 'valid', 'test', 'deploy'
        '''
        dataset_filepaths = self.dataset_filepaths
        start_time = time.time()
        print('Load dataset... ', end='', flush=True)
        if self.parameters['token_pretrained_embedding_filepath'] != '':
            print('(loading pre-trained token embeddsings...', end='', flush=True)
            self.token_to_vector = utils_nlp.load_pretrained_token_embeddings(self.parameters) # a dictionary {'token': np.array(d_embeds)}
            print('done with loading embeddings.) ', end='', flush=True)



        # start reading token/label/character in dataset
        tokens, labels, label_count, token_count, character_count = {}, {}, {}, {}, {}
        for dataset_type in ['train', 'valid', 'test', 'deploy']:
            labels[dataset_type], tokens[dataset_type], token_count[dataset_type], label_count[dataset_type], character_count[dataset_type] = self._parse_dataset(dataset_filepaths.get(dataset_type, None))

        token_count['all'] = {}
        for token in list(token_count['train'].keys()) + list(token_count['valid'].keys()) + list(token_count['test'].keys()) + list(token_count['deploy'].keys()):
            token_count['all'][token] = token_count['train'][token] + token_count['valid'][token] + token_count['test'][token] + token_count['deploy'][token]

        if self.parameters['load_all_pretrained_token_embeddings']:
            for token in self.token_to_vector:
                if token not in token_count['all']:
                    token_count['all'][token] = -1
                    token_count['train'][token] = -1


        character_count['all'] = {}
        for character in list(character_count['train'].keys()) + list(character_count['valid'].keys()) + list(character_count['test'].keys()) + list(character_count['deploy'].keys()):
            character_count['all'][character] = character_count['train'][character] + character_count['valid'][character] + character_count['test'][character] + character_count['deploy'][character]


        label_count['all'] = {}
        for character in list(label_count['train'].keys()) + list(label_count['valid'].keys()) + list(label_count['test'].keys()) + list(label_count['deploy'].keys()):
            label_count['all'][character] = label_count['train'][character] + label_count['valid'][character] + label_count['test'][character] + label_count['deploy'][character]

        token_count['all'] = utils.order_dictionary(token_count['all'], 'value_key', reverse = True)
        label_count['all'] = utils.order_dictionary(label_count['all'], 'key', reverse = False)
        character_count['all'] = utils.order_dictionary(character_count['all'], 'value', reverse = True)

        token_to_index = {}
        token_to_index[self.UNK] = self.UNK_TOKEN_INDEX
        iteration_number = 1 # for batch_size
        number_of_unknown_tokens = 0
        for token, count in token_count['all'].items():
            if iteration_number == self.UNK_TOKEN_INDEX: iteration_number += 1

            if self.parameters['remap_unknown_tokens_to_unk'] == 1 and \
                (token_count['train'][token] == 0 or \
                self.parameters['load_only_pretrained_token_embeddings']) and \
                not utils_nlp.is_token_in_pretrained_embeddings(token, self.token_to_vector, self.parameters):
                token_to_index[token] =  self.UNK_TOKEN_INDEX
                number_of_unknown_tokens += 1
                self.tokens_mapped_to_unk.append(token)
            else:
                token_to_index[token] = iteration_number
                iteration_number += 1
        if self.verbose: print("number_of_unknown_tokens: {0}".format(number_of_unknown_tokens))

        infrequent_token_indices = []
        for token, count in token_count['train'].items():
            if 0 < count <= self.map2unk_threshold:
                infrequent_token_indices.append(token_to_index[token])

        self.infrequent_token_indices = infrequent_token_indices


        # Ensure that both B- and I- versions exist for each label
        labels_without_bio = set()
        for label in label_count['all'].keys():
            new_label = utils_nlp.remove_bio_from_label_name(label)
            labels_without_bio.add(new_label)
        for label in labels_without_bio:
            if label == 'O':
                continue
            if self.parameters['tagging_format'] == 'bioes':
                prefixes = ['B-', 'I-', 'E-', 'S-']
            else:
                prefixes = ['B-', 'I-']
            for prefix in prefixes:
                l = prefix + label
                if l not in label_count['all']:
                    label_count['all'][l] = 0
        label_count['all'] = utils.order_dictionary(label_count['all'], 'key', reverse = False)

        # else:
        label_to_index = {}
        iteration_number = 0 # for batch_size
        for label, count in label_count['all'].items():
            label_to_index[label] = iteration_number
            iteration_number += 1
            self.unique_labels.append(label)

        if self.verbose: print('self.unique_labels: {0}'.format(self.unique_labels))

        character_to_index = {}
        iteration_number = 0
        for character, count in character_count['all'].items():
            if iteration_number == self.PADDING_CHARACTER_INDEX: iteration_number += 1
            character_to_index[character] = iteration_number
            iteration_number += 1

        token_to_index = utils.order_dictionary(token_to_index, 'value', reverse = False)
        index_to_token = utils.reverse_dictionary(token_to_index)
        if self.parameters['remap_unknown_tokens_to_unk'] == 1: index_to_token[self.UNK_TOKEN_INDEX] = self.UNK

        label_to_index = utils.order_dictionary(label_to_index, 'value', reverse = False)
        index_to_label = utils.reverse_dictionary(label_to_index)

        character_to_index = utils.order_dictionary(character_to_index, 'value', reverse = False)
        index_to_character = utils.reverse_dictionary(character_to_index)

        self.token_to_index = token_to_index
        self.index_to_token = index_to_token
        self.index_to_character = index_to_character
        self.character_to_index = character_to_index
        self.index_to_label = index_to_label
        self.label_to_index = label_to_index
        self.tokens = tokens
        self.labels = labels

        token_indices, label_indices, character_indices_padded, character_indices, token_lengths, characters, label_vector_indices = self._convert_to_indices(dataset_filepaths.keys())

        self.token_indices = token_indices
        self.label_indices = label_indices
        self.character_indices_padded = character_indices_padded
        self.character_indices = character_indices
        self.token_lengths = token_lengths
        self.characters = characters
        self.label_vector_indices = label_vector_indices

        self.number_of_classes = max(self.index_to_label.keys()) + 1
        self.vocabulary_size = max(self.index_to_token.keys()) + 1
        self.alphabet_size = max(self.index_to_character.keys()) + 1

        self.unique_labels_of_interest = list(self.unique_labels)
        self.unique_labels_of_interest.remove('O')

        self.unique_label_indices_of_interest = []
        for lab in self.unique_labels_of_interest:
            self.unique_label_indices_of_interest.append(label_to_index[lab])

        elapsed_time = time.time() - start_time
        print('done ({0:.2f} seconds)'.format(elapsed_time))

        if self.parameters['token_pretrained_embedding_filepath'] != '':
            self.embedding_matrix = self.load_pretrained_token_embeddings()

        return


    def _parse_dataset_with_tokenizer(self, dataset_filepath):
        '''
        Read tokens/labels in specific train/valid/test/deploy dataset
        and return their frequency table
        '''
        # token_count = collections.defaultdict(lambda: 0) # comment by yp
        label_count = collections.defaultdict(lambda: 0)
        character_count = collections.defaultdict(lambda: 0)

        line_count = -1
        tokens = []
        labels = []
        valid_tokens_index = []

        new_token_sequence = ['[CLS]'] # must include [CLS] at the start of each sentence to make padding index as 0 valid during training
        new_label_sequence = []
        new_valid_sequence = []
        if dataset_filepath:
            f = codecs.open(dataset_filepath, 'r', 'UTF-8')
            for line in f: # line: token label else_info(?)
                line_count += 1

                line = line.strip().split(' ')
                if len(line) == 0 or len(line[0]) == 0 or '-DOCSTART-' in line[0]:
                    # if len(new_token_sequence) > 0:
                    if len(new_label_sequence) > 0:
                        labels.append(new_label_sequence)
                        tokens.append(new_token_sequence)
                        valid_tokens_index.append(new_valid_sequence)
                        new_token_sequence = ['[CLS]']
                        new_label_sequence = []
                        new_valid_sequence = []
                    continue
                new_valid_sequence.append(len(new_token_sequence))
                # token = str(line[0]) # comment by yp
                token = self.tokenizer.tokenize(str(line[0]))
                label = str(line[-1])
                # token_count[token] += 1 # comment by yp
                label_count[label] += 1 # comment by yp

                # new_token_sequence.append(token) # comment by yp
                new_token_sequence += token
                new_label_sequence.append(label)

                for character in token:
                    character_count[character] += 1

                # if self.debug and line_count > 200: break# for debugging purposes

            # to include last sentence in dataset
            # if len(new_token_sequence) > 0:
            if len(new_label_sequence) > 0:
                labels.append(new_label_sequence)
                tokens.append(new_token_sequence)
                valid_tokens_index.append(new_valid_sequence)
            f.close()
        return labels, tokens, valid_tokens_index, label_count, character_count



    def load_dataset_from_pretrained(self):
        '''
        Tokenize words in dataset via pre-trained tokenizer
        '''
        dataset_filepaths = self.dataset_filepaths
        start_time = time.time()
        print('Load dataset... ', end='', flush=True)

        self.tokenizer = AutoTokenizer.from_pretrained(self.parameters['pretrained_transformer_name'])
        self.UNK_TOKEN_INDEX = self.tokenizer.convert_tokens_to_ids('[UNK]')

        # start reading token/label/character in dataset
        tokens, labels, label_count, valid_tokens_index, character_count = {}, {}, {}, {}, {}
        for dataset_type in ['train', 'valid', 'test', 'deploy']:
            labels[dataset_type], tokens[dataset_type], valid_tokens_index[dataset_type], label_count[dataset_type], character_count[dataset_type] = self._parse_dataset_with_tokenizer(dataset_filepaths.get(dataset_type, None))

        character_count['all'] = {}
        for character in list(character_count['train'].keys()) + list(character_count['valid'].keys()) + list(character_count['test'].keys()) + list(character_count['deploy'].keys()):
            character_count['all'][character] = character_count['train'][character] + character_count['valid'][character] + character_count['test'][character] + character_count['deploy'][character]

        label_count['all'] = {}
        for character in list(label_count['train'].keys()) + list(label_count['valid'].keys()) + list(label_count['test'].keys()) + list(label_count['deploy'].keys()):
            label_count['all'][character] = label_count['train'][character] + label_count['valid'][character] + label_count['test'][character] + label_count['deploy'][character]

        label_count['all'] = utils.order_dictionary(label_count['all'], 'key', reverse = False)
        character_count['all'] = utils.order_dictionary(character_count['all'], 'value', reverse = True)


        token_to_index = self.tokenizer.get_vocab() # get_vocab() return dictionary {'token': index} for tokenizer

        # Ensure that both B- and I- versions exist for each label
        labels_without_bio = set()
        for label in label_count['all'].keys():
            new_label = utils_nlp.remove_bio_from_label_name(label)
            labels_without_bio.add(new_label)
        for label in labels_without_bio:
            if label == 'O':
                continue
            if self.parameters['tagging_format'] == 'bioes':
                prefixes = ['B-', 'I-', 'E-', 'S-']
            else:
                prefixes = ['B-', 'I-']
            for prefix in prefixes:
                l = prefix + label
                if l not in label_count['all']:
                    label_count['all'][l] = 0
        label_count['all'] = utils.order_dictionary(label_count['all'], 'key', reverse = False)

        label_to_index = {}
        iteration_number = 0
        for label, count in label_count['all'].items():
            label_to_index[label] = iteration_number
            iteration_number += 1
            self.unique_labels.append(label)

        character_to_index = {}
        iteration_number = 0
        for character, count in character_count['all'].items():
            if iteration_number == self.PADDING_CHARACTER_INDEX: iteration_number += 1
            character_to_index[character] = iteration_number
            iteration_number += 1

        token_to_index = utils.order_dictionary(token_to_index, 'value', reverse = False)
        index_to_token = utils.reverse_dictionary(token_to_index)

        label_to_index = utils.order_dictionary(label_to_index, 'value', reverse = False)
        index_to_label = utils.reverse_dictionary(label_to_index)

        character_to_index = utils.order_dictionary(character_to_index, 'value', reverse = False)
        index_to_character = utils.reverse_dictionary(character_to_index)

        # To-Fill fields (delete later, just for reference)
        # self.token_to_vector = None # not needed to be filled when using pretrained tokenizer
        # self.embedding_matrix = None # not needed to be filled when using pretrained tokenizer

        self.index_to_token = index_to_token
        self.token_to_index = token_to_index
        self.index_to_character = index_to_character
        self.character_to_index = character_to_index
        self.index_to_label = index_to_label
        self.label_to_index = label_to_index
        self.tokens = tokens # storing bpes for dataset
        self.labels = labels
        self.valid_tokens_index = valid_tokens_index

        token_indices, label_indices, character_indices_padded, character_indices, token_lengths, characters, label_vector_indices = self._convert_to_indices(dataset_filepaths.keys())

        self.token_indices = token_indices
        self.label_indices = label_indices
        self.character_indices_padded = character_indices_padded
        self.character_indices = character_indices
        self.token_lengths = token_lengths
        self.characters = characters
        self.label_vector_indices = label_vector_indices

        self.number_of_classes = max(self.index_to_label.keys()) + 1
        self.vocabulary_size = max(self.index_to_token.keys()) + 1
        self.alphabet_size = max(self.index_to_character.keys()) + 1

        self.unique_labels_of_interest = list(self.unique_labels)
        self.unique_labels_of_interest.remove('O')

        self.unique_label_indices_of_interest = []
        for lab in self.unique_labels_of_interest:
            self.unique_label_indices_of_interest.append(label_to_index[lab])

        elapsed_time = time.time() - start_time
        print('done ({0:.2f} seconds)'.format(elapsed_time))

        return
