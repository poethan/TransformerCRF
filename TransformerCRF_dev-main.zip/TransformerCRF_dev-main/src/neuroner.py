'''
batch_size could be larger than 1 in this version
'''

import os, glob, codecs, shutil, time, copy, random, re
import pickle
import numpy as np
import matplotlib
matplotlib.use('Agg')
import tensorflow as tf
# from tensorflow.contrib.tensorboard.plugins import projector $ TF1
from tensorboard.plugins import projector
# from tensorflow.python.keras.backend import set_session # TF1
# from tensorflow.python.keras import backend as K # TF1
# from tensorflow.python.keras.models import load_model
import tensorflow_addons as tfa # TF2
from tensorflow.python.keras.utils.layer_utils import count_params
import distutils.util
import configparser
from pprint import pprint

import utils, utils_nlp, evaluate, brat_to_conll, conll_to_brat
from dataset import Dataset
from entity_transformer import EntityTransformer
# import utils

os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3' # ?
random.seed(123)

import warnings
warnings.filterwarnings('ignore')

print('TensorFlow version: {0}'.format(tf.__version__))
tf.config.run_functions_eagerly(True)

train_step_signature = [
    tf.TensorSpec(shape=(None, None), dtype=tf.int64),
    tf.TensorSpec(shape=(None, None, None), dtype=tf.int64),
    tf.TensorSpec(shape=(None, None), dtype=tf.int64)
]


class NeuroNER(object):
    def __init__(self, parameters_filepath):
        super(NeuroNER, self).__init__()

        parameters, parameters_ini = self._load_parameters(parameters_filepath)

        self.parameters = parameters
        self.parameters_ini = parameters_ini

        self.dataset = Dataset(parameters)
        if self.parameters['use_pretrained_transformer']:
            self.dataset.load_dataset_from_pretrained()
        else:
            self.dataset.load_dataset_from_scratch()

        # Launch session: for TF1
        # session_conf = tf.ConfigProto(
        # intra_op_parallelism_threads=parameters['number_of_cpu_threads'],
        # inter_op_parallelism_threads=parameters['number_of_cpu_threads'],
        # device_count={'CPU': 1, 'GPU': parameters['number_of_gpus']},
        # allow_soft_placement=True, # automatically choose an existing and supported device to run the operations in case the specified one doesn't exist
        # log_device_placement=False
        # )
        # self.sess = tf.Session(config=session_conf)
        # # sess = K.get_session(config=session_conf)
        # self.graph = tf.get_default_graph()

        # with self.sess.as_default():
        #     set_session(self.sess)
        #     self.model = EntityTransformer(num_layers=6, d_model=512, num_heads=8, dff=2048,
        #     input_vocab_size=self.dataset.vocabulary_size, rate=0.1, use_crf=parameters['use_crf'],
        #     number_of_classes=self.dataset.number_of_classes, sess=self.sess)
        #
        #     # initialize model weights
        #     self.sess.run(tf.global_variables_initializer())
        #     # self.sess.run(tf.initialize_all_variables())
        #     if not parameters['use_pretrained_model']:
        #         self.transition_params_trained = np.random.rand(len(self.dataset.unique_labels)+2,len(self.dataset.unique_labels)+2)
        #     else:
        #         self.transition_params_trained = self.model.restore_from_pretrained_model(parameters, dataset, sess, token_to_vector=token_to_vector)


        # setup model on TF2
        self.model = EntityTransformer(num_layers=self.parameters['transformer_num_layers'],
        max_sequence=self.parameters['transformer_max_sequence'],
        d_model=self.parameters['transformer_d_model'],
        num_heads=self.parameters['transformer_num_heads'],
        dff=self.parameters['transformer_dff'],
        input_vocab_size=self.dataset.vocabulary_size,
        freeze_token_embeddings=self.parameters['freeze_token_embeddings'],
        token_embedding_matrix=self.dataset.embedding_matrix,
        rate=self.parameters['dropout_rate'],
        pretrained_transformer_name=self.parameters['pretrained_transformer_name'],
        use_pretrained_transformer=self.parameters['use_pretrained_transformer'],
        use_crf=parameters['use_crf'], number_of_classes=self.dataset.number_of_classes)

        # if self.parameters['token_pretrained_embedding_filepath'] != '':
        #     # initialize embedding layer in model.transformer.encoder.embedding
        #     if self.dataset.token_to_vector == None:
        #         raise ValueError('Loading pre-trained token embeddings fails and there is nothing in token_to_index.')
        #     else:
        #         print('Filling pre-trained token embeddings to model...')
        #     embedding_matrix = np.zeros((self.dataset.vocabulary_size, self.parameters['token_embedding_dimension']))
        #
        #     for token in self.dataset.token_to_index.keys():
        #         token_lower = token.lower()
        #         token_no_digits = re.sub(r'\d', '0', token)
        #         token_lower_no_digits = re.sub(r'\d', '0', token_lower)
        #         if token in self.dataset.token_to_vector.keys():
        #             embedding_matrix[self.dataset.token_to_index[token]] = self.dataset.token_to_vector[token]
        #         elif self.parameters['check_for_lowercase'] and token_lower in self.dataset.token_to_vector.keys():
        #             embedding_matrix[self.dataset.token_to_index[token]] = self.dataset.token_to_vector[token_lower]
        #         elif self.parameters['check_for_digits_replaced_with_zeros'] and token_no_digits in self.dataset.token_to_vector.keys():
        #             embedding_matrix[self.dataset.token_to_index[token]] = self.dataset.token_to_vector[token_no_digits]
        #         elif self.parameters['check_for_lowercase'] and self.parameters['check_for_digits_replaced_with_zeros'] and token_lower_no_digits in self.dataset.token_to_vector.keys():
        #             embedding_matrix[self.dataset.token_to_index[token]] = self.dataset.token_to_vector[token_lower_no_digits]
        #         else:
        #             continue
        #     self.model.transformer.encoder.embedding.build((None, ))
        #     self.model.transformer.encoder.embedding.set_weights(embedding_matrix)
        #     print('Done with filling pre-trained token embeddings.')

        # if not parameters['use_pretrained_model']:
        #     self.transition_params_trained = np.random.rand(len(self.dataset.unique_labels)+2,len(self.dataset.unique_labels)+2)
        # else:
        #     self.transition_params_trained = self.model.restore_from_pretrained_model(parameters, dataset, sess, token_to_vector=token_to_vector) # ? to modify
        self.transition_params_trained = None


        # set optimier
        if parameters['optimizer'] == 'adam':
            self.optimizer = tf.keras.optimizers.Adam(learning_rate=parameters['learning_rate'],
            beta_1=0.9, beta_2=0.98, epsilon=1e-9) # TF2
            # self.optimizer = tf.train.AdamOptimizer(learning_rate=parameters['learning_rate']) # TF1
        elif parameters['optimizer'] == 'sgd':
            self.optimizer = tf.keras.optimizers.SGD(parameters['learning_rate']) # TF2
            # self.optimizer = tf.train.GradientDescentOptimizer(parameters['learning_rate']) # TF1
        elif parameters['optimizer'] == 'adadelta':
            self.optimizer = tf.keras.optimizers.Adadelta(parameters['learning_rate']) # TF2
            # self.optimizer = tf.train.AdadeltaOptimizer(parameters['learning_rate']) # TF1
        else:
            raise ValueError('The optimizer must be either adadelta, adam or sgd.')

        # self.global_step = tf.Variable(0, name="global_step", trainable=False) # for TF1
        # self.sess.run(self.global_step.initializer) # for TF1


    def _create_stats_graph_folder(self):
        experiment_timestamp = utils.get_current_time_in_miliseconds()
        dataset_name = utils.get_basename_without_extension(self.parameters['dataset_text_folder'])
        model_name = '{0}_{1}'.format(dataset_name, experiment_timestamp)
        utils.create_folder_if_not_exists(self.parameters['output_folder'])
        stats_graph_folder = os.path.join(self.parameters['output_folder'], model_name) # Folder where to save graphs
        utils.create_folder_if_not_exists(stats_graph_folder)
        return stats_graph_folder, experiment_timestamp


    def _load_parameters(self, path, verbose=True):
        parser = configparser.ConfigParser()
        parser.read(path)
        params_ini = {s:dict(parser.items(s)) for s in parser.sections()}
        params = {}
        for k, v in params_ini.items():
           for kk, vv in v.items():
               params[kk] = vv

        # check type of parameter
        for k, v in params.items():
            v = str(v)
            if ',' in v:
                v = random.choice(v.split(','))
                params[k] = v
            if k in ['transformer_num_layers', 'transformer_max_sequence', 'transformer_d_model', 'transformer_num_heads', 'transformer_dff',
            'token_embedding_dimension', 'batch_size', 'patience','maximum_number_of_epochs','number_of_cpu_threads','number_of_gpus']:
                params[k] = int(v)
            elif k in ['dropout_rate', 'learning_rate', 'gradient_clipping_value']:
                params[k] = float(v)
            elif k in ['remap_unknown_tokens_to_unk', 'use_crf', 'train_model', 'use_pretrained_transformer', 'verbose', 'freeze_token_embeddings',
                     # 'reload_character_embeddings', 'reload_character_transformer', 'reload_token_embeddings', 'reload_token_transformer', 'reload_feedforward', 'reload_crf',
                     'check_for_lowercase', 'check_for_digits_replaced_with_zeros', 'load_only_pretrained_token_embeddings', 'load_all_pretrained_token_embeddings',
                     'split_discontinuous']: # ? need to further modify
                params[k] = distutils.util.strtobool(v)

        if params['gradient_clipping_value'] < 0:
            params['gradient_clipping_value'] = abs(params['gradient_clipping_value'])

        # if params['use_pretrained_model']:
        #     pretraining_parameters = self._load_parameters(parameters_filepath=os.path.join(params['pretrained_model_folder'], 'parameters.ini'), verbose=False)
        #     for name in ['token_embedding_dimension', 'use_crf']:
        #         if params[name] != pretraining_parameters[name]:
        #             print('WARNING: parameter {0} was overwritten from {1} to {2} to be consistent with the pretrained model'.format(name, parameters[name], pretraining_parameters[name]))
        #             params[name] = pretraining_parameters[name]

        if verbose: pprint(params)

        return params, parser

    def fit(self):
        if self.parameters['checkpoint_path'] != '':
            subfolders = self.parameters['checkpoint_path'].split('/')
            stats_graph_folder = '/'.join(subfolders[:-1])
            experiment_timestamp = '_'.join(subfolders[-2].split('_')[1:])
        else:
            stats_graph_folder, experiment_timestamp = self._create_stats_graph_folder()
            self.parameters['checkpoint_path'] = os.path.join(stats_graph_folder, 'model')


        start_time = time.time()

        results = {}
        results['epoch'] = {}
        results['execution_details'] = {}
        results['execution_details']['train_start'] = start_time
        results['execution_details']['time_stamp'] = experiment_timestamp
        results['execution_details']['early_stop'] = False
        results['execution_details']['keyboard_interrupt'] = False
        results['execution_details']['num_epochs'] = 0
        results['model_options'] = copy.copy(self.parameters)

        # prepartion part: save parameters, dataset, token2index, character2index files

        model_folder = os.path.join(stats_graph_folder, 'model')
        utils.create_folder_if_not_exists(model_folder)
        with open(os.path.join(model_folder, 'parameters.ini'), 'w') as parameters_file:
            self.parameters_ini.write(parameters_file)
        pickle.dump(self.dataset, open(os.path.join(model_folder, 'dataset.pickle'), 'wb'))

        tensorboard_log_folder = os.path.join(stats_graph_folder, 'tensorboard_logs')
        utils.create_folder_if_not_exists(tensorboard_log_folder)
        tensorboard_log_folders = {}
        for dataset_type in self.dataset.dataset_filepaths.keys():
            tensorboard_log_folders[dataset_type] = os.path.join(stats_graph_folder, 'tensorboard_logs', dataset_type)
            utils.create_folder_if_not_exists(tensorboard_log_folders[dataset_type])

        # Instantiate the writers for TensorBoard
        writers = {}
        for dataset_type in self.dataset.dataset_filepaths.keys():
            # writers[dataset_type] = tf.summary.FileWriter(tensorboard_log_folders[dataset_type], graph=self.sess.graph) # TF1
            writers[dataset_type] = tf.summary.create_file_writer(tensorboard_log_folders[dataset_type]) # TF2
        # embedding_writer = tf.summary.FileWriter(model_folder) # TF1: embedding_writer has to write in model_folder, otherwise TensorBoard won't be able to view embeddings
        embedding_writer = tf.summary.create_file_writer(model_folder) # TF2

        embeddings_projector_config = projector.ProjectorConfig()
        tensorboard_token_embeddings = embeddings_projector_config.embeddings.add()
        tensorboard_token_embeddings.tensor_name = 'token_embedding_weights'
        token_list_file_path = os.path.join(model_folder, 'tensorboard_metadata_tokens.tsv')
        tensorboard_token_embeddings.metadata_path = os.path.relpath(token_list_file_path, '..')

        tensorboard_character_embeddings = embeddings_projector_config.embeddings.add()
        tensorboard_character_embeddings.tensor_name = 'character_embedding_weights'   # Ghada: I commented this for char emb problem
        character_list_file_path = os.path.join(model_folder, 'tensorboard_metadata_characters.tsv')
        tensorboard_character_embeddings.metadata_path = os.path.relpath(character_list_file_path, '..')

        # projector.visualize_embeddings(embedding_writer, embeddings_projector_config) # ?
        projector.visualize_embeddings(model_folder, embeddings_projector_config)

        # Write metadata for TensorBoard embeddings
        token_list_file = codecs.open(token_list_file_path,'w', 'UTF-8')
        for token_index in range(1, self.dataset.vocabulary_size):
            token_list_file.write('{0}\n'.format(self.dataset.index_to_token[token_index]))
        token_list_file.close()

        character_list_file = codecs.open(character_list_file_path,'w', 'UTF-8')
        for character_index in range(self.dataset.alphabet_size):
            if character_index == self.dataset.PADDING_CHARACTER_INDEX:
                character_list_file.write('PADDING\n')
            else:
                character_list_file.write('{0}\n'.format(self.dataset.index_to_character[character_index]))
        character_list_file.close()


        # training process
        # Start training + evaluation loop. Each iteration corresponds to 1 epoch.
        bad_counter = 0 # number of epochs with no improvement on the validation test in terms of F1-score
        previous_best_valid_f1_score = 0
        epoch_number = 0
        train_data_instances = self.dataset.token_indices['train']
        train_label_vectors = self.dataset.label_vector_indices['train']
        train_label_vectors_flat = self.dataset.label_indices['train']
        if self.parameters['use_pretrained_transformer']:
            train_data_valid_indices = self.dataset.valid_tokens_index['train']
        else:
            train_data_valid_indices = None
        infrequent_token_indices = self.dataset.infrequent_token_indices
        # saver = tf.train.Saver(max_to_keep=self.parameters['maximum_number_of_epochs'])  # TF1: defaults to saving all variables
        ckpt = tf.train.Checkpoint(model=self.model, optimizer=self.optimizer) # TF2
        ckpt_manager = tf.train.CheckpointManager(ckpt, self.parameters['checkpoint_path'], max_to_keep=self.parameters['maximum_number_of_epochs']) # TF2
        if ckpt_manager.latest_checkpoint:
            ckpt.restore(ckpt_manager.latest_checkpoint)
            print('Latest checkpoint restored!!')
            epoch_number = int(ckpt_manager.latest_checkpoint.split(sep='ckpt-')[-1]) # to check?
            print('Start train from epoch ', epoch_number)
            if self.parameters['use_crf']:
                self.transition_params_trained = self.model.crf.transition_parameters
            else:
                self.transition_params_trained = None
        else:
            print('Start training model from scratch!')
            self.transition_params_trained = np.random.rand(len(self.dataset.unique_labels)+2,len(self.dataset.unique_labels)+2)

        transition_params_trained = self.transition_params_trained

        batch_size = self.parameters['batch_size']
        if len(train_data_instances)% batch_size== 0:
            total_train_batch = int(len(train_data_instances)/batch_size)
        else:
            total_train_batch = int(len(train_data_instances)/batch_size) + 1

        try:
            trainable_count = count_params(self.model.trainable_weights)
            non_trainable_count = count_params(self.model.non_trainable_weights)
            print('Total params: {:,}'.format(trainable_count + non_trainable_count))
            print('Trainable params: {:,}'.format(trainable_count))
            print('Non-trainable params: {:,}'.format(non_trainable_count))
        except:
            continue

        try:
            while True:
                # step = 0
                epoch_number += 1
                print('\nStarting epoch {0}'.format(epoch_number))

                epoch_start_time = time.time()

                if epoch_number != 1:
                    # Train model: loop over all sequences of training set with shuffling
                    sequence_numbers = list(range(len(train_data_instances)))
                    random.shuffle(sequence_numbers)

                    # implementing batch size
                    # print('Before back propogation in this epoch, transition matrix from CRF layer is {}'.format(self.model.crf.transition_parameters))
                    for batch_cnt in range(0, total_train_batch):
                        batch_start_idx, batch_end_idx = batch_cnt * batch_size, (batch_cnt + 1)*batch_size
                        batch_sequence_numbers = sequence_numbers[batch_start_idx : batch_end_idx]
                        batch_token_indices_sequence, batch_train_label_vectors, batch_train_label_vectors_flat, batch_train_valid_indices = [], [], [], []
                        max_batch_bpe_seq_length, max_batch_word_seq_length = 0, 0

                        for sequence_number in batch_sequence_numbers:
                            token_indices_sequence = train_data_instances[sequence_number]
                            for i, token_index in enumerate(token_indices_sequence):
                                if token_index in infrequent_token_indices and np.random.uniform() < 0.5:
                                    token_indices_sequence[i] = self.dataset.UNK_TOKEN_INDEX

                            batch_token_indices_sequence.append(token_indices_sequence)
                            batch_train_label_vectors.append(train_label_vectors[sequence_number].tolist())
                            batch_train_label_vectors_flat.append(train_label_vectors_flat[sequence_number])

                            if len(token_indices_sequence) > max_batch_bpe_seq_length:
                                max_batch_bpe_seq_length = len(token_indices_sequence)
                            if self.parameters['use_pretrained_transformer']:
                                batch_train_valid_indices.append(train_data_valid_indices[sequence_number])
                                if len(train_data_valid_indices[sequence_number]) > max_batch_word_seq_length:
                                    max_batch_word_seq_length = len(train_data_valid_indices[sequence_number])
                            else:
                                max_batch_word_seq_length = max_batch_bpe_seq_length


                        # padding for batch input and convert to tensor
                        batch_token_indices_sequence_padded = tf.constant([sequence+[0]*(max_batch_bpe_seq_length-len(sequence)) for sequence in batch_token_indices_sequence])
                        batch_train_label_vectors_padded = tf.constant([vector+[[0]*self.dataset.number_of_classes]*(max_batch_word_seq_length-len(vector)) for vector in batch_train_label_vectors])
                        batch_train_label_vectors_flat_padded = tf.constant([vector+[-1]*(max_batch_word_seq_length-len(vector)) for vector in batch_train_label_vectors_flat])
                        batch_train_valid_indices_padded = tf.constant([vector+[0]*(max_batch_word_seq_length-len(vector)) for vector in batch_train_valid_indices])


                        # pass input to model
                        self.train_step(batch_token_indices_sequence_padded, batch_train_label_vectors_padded, batch_train_label_vectors_flat_padded, batch_train_valid_indices_padded)
                        if self.parameters['use_crf']:
                            transition_params_trained = self.model.crf.transition_parameters # ?
                        else:
                            transition_params_trained = None

                        # step += 1
                        if (batch_cnt+1)% 10 == 0:
                            print('Training {0:.2f}% done'.format((batch_cnt+1)/total_train_batch*100), end='\r', flush=True)

                # print('After back propogation in this epoch, transition matrix from CRF layer is {}'.format(self.model.crf.transition_parameters))


                epoch_elapsed_training_time = time.time() - epoch_start_time
                print('Training completed in {0:.2f} seconds'.format(epoch_elapsed_training_time), flush=True)

                # prediction and evaluation
                y_pred, y_true, output_filepaths = {}, {}, {}
                for dataset_type in ['train', 'valid', 'test', 'deploy']:
                    if dataset_type not in self.dataset.dataset_filepaths.keys():
                        continue
                    y_pred[dataset_type], y_true[dataset_type], output_filepaths[dataset_type] = self.prediction_step(dataset_type, epoch_number, stats_graph_folder)

                # Evaluate model: save and plot results
                evaluate.evaluate_model(results, self.dataset, y_pred, y_true, stats_graph_folder, epoch_number, epoch_start_time, output_filepaths, self.parameters)

                # if self.parameters['use_pretrained_model'] and not self.parameters['train_model']:
                #     conll_to_brat.output_brat(output_filepaths, self.dataset.dataset_brat_folders, stats_graph_folder)
                #     break

                # Save model
                # saver.save(self.sess, os.path.join(model_folder, 'model_{0:05d}.ckpt'.format(epoch_number))) # TF 1
                ckpt_save_path = ckpt_manager.save() # TF 2
                print(f'Saving checkpoint for epoch {epoch_number} at {ckpt_save_path}')

                # Early stop
                valid_f1_score = results['epoch'][epoch_number][0]['valid']['f1_score']['micro']
                if valid_f1_score > previous_best_valid_f1_score:
                    bad_counter = 0
                    previous_best_valid_f1_score = valid_f1_score
                    conll_to_brat.output_brat(output_filepaths, self.dataset.dataset_brat_folders, stats_graph_folder, overwrite=True)
                    self.transition_params_trained = transition_params_trained
                else:
                    bad_counter += 1
                print("The last {0} epochs have not shown improvements on the validation set.".format(bad_counter))

                if bad_counter >= self.parameters['patience']:
                    print('Early Stop!')
                    results['execution_details']['early_stop'] = True
                    break

                if epoch_number >= self.parameters['maximum_number_of_epochs']: break


        except KeyboardInterrupt:
            results['execution_details']['keyboard_interrupt'] = True
            print('Training interrupted')

        print('Finishing the experiment')

        trainable_count = count_params(self.model.trainable_weights)
        non_trainable_count = count_params(self.model.non_trainable_weights)
        print('Total params: {:,}'.format(trainable_count + non_trainable_count))
        print('Trainable params: {:,}'.format(trainable_count))
        print('Non-trainable params: {:,}'.format(non_trainable_count))

        end_time = time.time()
        results['execution_details']['train_duration'] = end_time - start_time
        results['execution_details']['train_end'] = end_time
        evaluate.save_results(results, stats_graph_folder)
        for dataset_type in self.dataset.dataset_filepaths.keys():
            writers[dataset_type].close()
        return

    @tf.function(input_signature=train_step_signature)
    def train_step(self, input_token, gt_label_vectors, gt_label_vectors_flat, valid_inputs_indices):
        with tf.GradientTape() as tape:
            # loss, accuracy = self.model(batch_token_indices_sequence_padded, batch_train_label_vectors_padded, batch_train_label_vectors_flat_padded, training=True)
            loss, accuracy = self.model(input_token, gt_label_vectors, gt_label_vectors_flat, valid_inputs_indices, training=True)

        # print('Loss is {} and accuracy is {} '.format(loss, accuracy))
        # print('Trainable variables in model are ', self.model.trainable_variables)

        gradients = tape.gradient(loss, self.model.trainable_variables)
        # print('gradients are {} with type {} '.format(gradients, type(gradients)))
        if self.parameters['gradient_clipping_value']:
            # gradients = [(tf.clip_by_value(grad, -self.parameters['gradient_clipping_value'], self.parameters['gradient_clipping_value']), var)
            # for grad, var in gradients]
            gradients = [grad if grad is None else tf.clip_by_value(grad, -self.parameters['gradient_clipping_value'], self.parameters['gradient_clipping_value']) for grad in gradients]
        self.optimizer.apply_gradients(zip(gradients, self.model.trainable_variables))

        return

    def prediction_step(self, dataset_type, epoch_number, stats_graph_folder):
        if dataset_type == 'deploy':
            print('Predict labels for the {0} set'.format(dataset_type))
        else:
            print('Evaluate model on the {0} set'.format(dataset_type))

        all_predictions = []
        all_y_true = []
        output_filepath = os.path.join(stats_graph_folder, '{1:03d}_{0}.txt'.format(dataset_type, epoch_number))
        output_file = codecs.open(output_filepath, 'w', 'UTF-8')
        original_conll_file = codecs.open(self.dataset.dataset_filepaths[dataset_type], 'r', 'UTF-8')
        # print('token_indices are ', self.dataset.token_indices[dataset_type])

        # print('token_indices are ', self.dataset.token_indices[dataset_type])

        # prediction process
        # prepare input for model
        type_data_indices = self.dataset.token_indices[dataset_type]
        type_label_vectors = self.dataset.label_vector_indices[dataset_type]
        type_label_vectors_flat = self.dataset.label_indices[dataset_type]
        if self.parameters['use_pretrained_transformer']:
            type_data_valid_indices = self.dataset.valid_tokens_index[dataset_type]
        else:
            type_data_valid_indices = None
        total_type_data = len(type_data_indices)

        batch_size = self.parameters['batch_size']
        if total_type_data% batch_size== 0:
            total_type_batch = int(total_type_data/batch_size)
        else:
            total_type_batch = int(total_type_data/batch_size) + 1


        # implementing batch size
        for b_cnt in range(0, total_type_batch):
            # print('For {}-th batch, transition matrix from CRF layer is {}'.format(b_cnt, self.model.crf.transition_parameters))
            batch_type_token_indices, batch_type_label_vectors, batch_type_label_vectors_flat, batch_type_valid_indices = [], [], [], []
            max_batch_bpe_seq_length, max_batch_word_seq_length = 0, 0
            batch_valid_seq_lengths = []
            for idx in range(b_cnt * batch_size, (b_cnt + 1)*batch_size):
                if idx == total_type_data:
                    break
                # print('Before inputs are {} with type {}'.format(self.dataset.token_indices[dataset_type][idx], type(self.dataset.token_indices[dataset_type][idx])))
                # print('Before label are {} with type {}'.format(self.dataset.label_vector_indices[dataset_type][idx], type(self.dataset.label_vector_indices[dataset_type][idx])))
                # print('Before label_flat are {} with type {}'.format(self.dataset.label_indices[dataset_type][idx], type(self.dataset.label_indices[dataset_type][idx])))

                batch_type_token_indices.append(type_data_indices[idx])
                batch_type_label_vectors.append(type_label_vectors[idx].tolist())
                batch_type_label_vectors_flat.append(type_label_vectors_flat[idx])

                cur_seq_len = len(type_label_vectors_flat[idx])
                batch_valid_seq_lengths.append(cur_seq_len)

                if len(type_data_indices[idx]) > max_batch_bpe_seq_length:
                    max_batch_bpe_seq_length = len(type_data_indices[idx])
                if self.parameters['use_pretrained_transformer']:
                    batch_type_valid_indices.append(type_data_valid_indices[idx])
                    if len(type_data_valid_indices[idx]) > max_batch_word_seq_length:
                        max_batch_word_seq_length = len(type_data_valid_indices[idx])
                else:
                    max_batch_word_seq_length = max_batch_bpe_seq_length

            # padding for batch input and convert to tensor
            batch_type_token_indices_padded = tf.constant([sequence+[0]*(max_batch_bpe_seq_length-len(sequence)) for sequence in batch_type_token_indices]) # (batch_size, max_seq_len)
            batch_type_label_vectors_padded = tf.constant([vector+[[0]*self.dataset.number_of_classes]*(max_batch_word_seq_length-len(vector)) for vector in batch_type_label_vectors]) # (batch_size, max_seq_len, #class)
            batch_type_label_vectors_flat_padded = tf.constant([vector+[-1]*(max_batch_word_seq_length-len(vector)) for vector in batch_type_label_vectors_flat]) # (batch_size, max_seq_len)
            batch_type_valid_indices_padded = tf.constant([vector+[0]*(max_batch_word_seq_length-len(vector)) for vector in batch_type_valid_indices])

            # print('batch_type_token_indices_padded size is ', batch_type_token_indices_padded.shape)
            # print('batch_type_token_indices_padded size is ', batch_type_label_vectors_padded.shape)
            # print('batch_type_token_indices_padded size is ', batch_type_label_vectors_padded.shape)
            # print('batch_type_valid_indices_padded size is ', batch_type_valid_indices_padded.shape)


            # run model
            # _, _ = self.sess.run(self.model(batch_type_token_indices_padded, batch_type_label_vectors_padded, batch_type_label_vectors_flat_padded)) # TF 1
            _, _ = self.model(batch_type_token_indices_padded, batch_type_label_vectors_padded, batch_type_label_vectors_flat_padded, batch_type_valid_indices_padded, training=False) # TF 2

            # print("model summary is ", self.model.summary())
            # print('Transformer weights after initialized ', self.model.ff_before_crf.get_weights())
            # print('crf weights after initialized ', self.model.crf.transition_parameters)

            if self.parameters['use_crf']:
                # print('unary scores before are ', self.model.unary_scores)
                # print('transition parameters are ', self.model.crf.transition_parameters)
                unary_scores = self.model.unary_scores.numpy()
                trans_params = tf.identity(self.model.crf.transition_parameters).numpy()

                # unary_scores = self.sess.run(self.model.unary_scores) # (batch_size, max_seq_len+2, #class+2)
                # trans_params = self.sess.run(tf.identify(self.model.crf.transition_parameters))

                # print('unary scores after eval() are ',unary_scores)
                # print('transition parameters after eval() are ',trans_params)
            else:
                batch_predictions = self.model.predictions.numpy().tolist()

            for b_idx, i in enumerate(range(b_cnt * batch_size, (b_cnt + 1)*batch_size)):
                if i == total_type_data:
                    break
                if self.parameters['use_crf']:
                    cur_unary_scores = unary_scores[b_idx][1:(batch_valid_seq_lengths[b_idx]+1)]
                    predictions, _ = tfa.text.crf.viterbi_decode(cur_unary_scores, trans_params)
                else:
                    predictions = batch_predictions[b_idx][:batch_valid_seq_lengths[b_idx]]

                # print('Before padding, predictions are ', predictions)
                non_entity_label = self.dataset.label_to_index['O']
                if len(predictions) < len(self.dataset.label_indices[dataset_type][i]):
                    predictions = predictions[:-1] + [non_entity_label]*(len(self.dataset.label_indices[dataset_type][i])-len(predictions)) + predictions[-1:]
                assert len(predictions) == len(self.dataset.label_indices[dataset_type][i])
                # print('After padding, predictions are ', predictions)
                predictions = [prediction if prediction < self.dataset.number_of_classes else non_entity_label for prediction in predictions]
                # print('After thresholding, predictions are ', predictions)

                output_string = ''
                prediction_labels = [self.dataset.index_to_label[prediction] for prediction in predictions]
                gold_labels = self.dataset.labels[dataset_type][i]
                # print('prediction labels are ', prediction_labels)
                # print('ground truth labels are ', gold_labels)

                if self.parameters['tagging_format'] == 'bioes':
                    prediction_labels = utils_nlp.bioes_to_bio(prediction_labels)
                    gold_labels = utils_nlp.bioes_to_bio(gold_labels)

                # codes added to match BPEs from BERT-style tokenizer to words: not finished yet
                # if self.parameters['use_pretrained_transformer']:
                #     bpes = self.dataset.tokens[dataset_type][i]
                #     token_indices = self.dataset.valid_tokens_index[dataset_type][i]
                #     tokens = []
                #     for tidx in range(len(token_indices)):
                #         if tidx < len(token_indices):
                #             sidx, eidx = token_indices[tidx], token_indices[tidx+1]
                #             tokens.append(''.join(bpes[sidx:eidx]))
                # else:
                #     tokens = self.dataset.tokens[dataset_type][i]

                for prediction, gold_label in zip(prediction_labels, gold_labels):
                    while True:
                        line = original_conll_file.readline()
                        split_line = line.strip().split(' ')
                        if '-DOCSTART-' in split_line[0] or len(split_line) == 0 or len(split_line[0]) == 0:
                            continue
                        else:
                            token_original = split_line[0]
                            if self.parameters['tagging_format'] == 'bioes':
                                split_line.pop()
                            gold_label_original = split_line[-1]
                            assert gold_label == gold_label_original
                            break
                    split_line.append(prediction)
                    output_string += ' '.join(split_line) + '\n'

                output_file.write(output_string+'\n')

                all_predictions.extend(predictions)
                all_y_true.extend(self.dataset.label_indices[dataset_type][i])

        output_file.close()
        original_conll_file.close()

        if dataset_type != 'deploy':
            if self.parameters['main_evaluation_mode'] == 'conll':
                conll_evaluation_script = os.path.join('.', 'conlleval')
                conll_output_filepath = '{0}_conll_evaluation.txt'.format(output_filepath)
                shell_command = 'perl {0} < {1} > {2}'.format(conll_evaluation_script, output_filepath, conll_output_filepath)
                os.system(shell_command)
                with open(conll_output_filepath, 'r') as f:
                    classification_report = f.read()
                    print(classification_report)
            else:
                new_y_pred, new_y_true, new_label_indices, new_label_names, _, _ = remap_labels(all_predictions, all_y_true, dataset, self.parameters['main_evaluation_mode'])
                print(sklearn.metrics.classification_report(new_y_true, new_y_pred, digits=4, labels=new_label_indices, target_names=new_label_names))


        assert len(all_predictions) == len(all_y_true)

        return all_predictions, all_y_true, output_filepath



    # def close(self):
    #     self.__del__()
    #
    # def __del__(self):
    #     self.sess.close()
