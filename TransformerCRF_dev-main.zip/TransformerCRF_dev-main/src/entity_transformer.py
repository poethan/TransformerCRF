'''
batch_size could be larger than 1 in this version
'''

import re, time, os, pickle
import numpy as np
import tensorflow as tf
import tensorflow_addons as tfa # TF2
from transformers import AutoTokenizer, TFAutoModel

def slice_3d_from_2d(x, idx):
    reshapedIdx = tf.reshape(idx, [-1]) # (batch_size * max_seq_len)
    idx_flattened = tf.reshape(tf.tile(tf.reshape(tf.range(tf.shape(x)[0]), [-1, 1]), [1, tf.shape(idx)[1]]), [-1]) * tf.shape(x)[1] + reshapedIdx
    y = tf.gather(tf.reshape(x, [-1, tf.shape(x)[2]]), idx_flattened)
    return tf.reshape(y, [tf.shape(x)[0], tf.shape(idx)[1], tf.shape(x)[2]])

# Transformer Encoder layer codes comes from https://www.tensorflow.org/text/tutorials/transformer

# MAX_TOKENS = 13 # mismatch between input length of training set and ground truth, problem for evaluation

# position encoding in Transformer encoder
def get_angles(pos, i, d_model):
    angle_rates = 1 / np.power(10000, (2 * (i//2)) / np.float32(d_model))
    return pos * angle_rates

def positional_encoding(position, d_model):
    angle_rads = get_angles(np.arange(position)[:, np.newaxis], np.arange(d_model)[np.newaxis, :], d_model)

    # apply sin to even indices in the array; 2i
    angle_rads[:, 0::2] = np.sin(angle_rads[:, 0::2])

    # apply cos to odd indices in the array; 2i+1
    angle_rads[:, 1::2] = np.cos(angle_rads[:, 1::2])

    pos_encoding = angle_rads[np.newaxis, ...]

    return tf.cast(pos_encoding, dtype=tf.float32)

# Masking
def create_padding_mask(seq):
    seq = tf.cast(tf.math.equal(seq, -1), tf.float32)

    # add extra dimensions to add the padding
    # to the attention logits.
    return seq[:, tf.newaxis, tf.newaxis, :]  # (batch_size, 1, 1, seq_len)

# Scaled dot product attention
def scaled_dot_product_attention(q, k, v, mask):
    """Calculate the attention weights.
    q, k, v must have matching leading dimensions.
    k, v must have matching penultimate dimension, i.e.: seq_len_k = seq_len_v.
    The mask has different shapes depending on its type(padding or look ahead)
    but it must be broadcastable for addition.

    Args:
    q: query shape == (..., seq_len_q, depth)
    k: key shape == (..., seq_len_k, depth)
    v: value shape == (..., seq_len_v, depth_v)
    mask: Float tensor with shape broadcastable
          to (..., seq_len_q, seq_len_k). Defaults to None.

    Returns:
    output, attention_weights
    """

    matmul_qk = tf.matmul(q, k, transpose_b=True)  # (..., seq_len_q, seq_len_k)

    # scale matmul_qk
    dk = tf.cast(tf.shape(k)[-1], tf.float32)
    scaled_attention_logits = matmul_qk / tf.math.sqrt(dk)

    # add the mask to the scaled tensor.
    if mask is not None:
        scaled_attention_logits += (mask * -1e9)

    # softmax is normalized on the last axis (seq_len_k) so that the scores
    # add up to 1.
    attention_weights = tf.nn.softmax(scaled_attention_logits, axis=-1)  # (..., seq_len_q, seq_len_k)
    output = tf.matmul(attention_weights, v)  # (..., seq_len_q, depth_v)

    return output, attention_weights

# Multi-head attention
class MultiHeadAttention(tf.keras.layers.Layer):
    def __init__(self,*, d_model=512, num_heads=8):
        super(MultiHeadAttention, self).__init__()
        self.num_heads = num_heads
        self.d_model = d_model

        assert d_model % self.num_heads == 0

        self.depth = d_model // self.num_heads
        self.wq = tf.keras.layers.Dense(d_model)
        self.wk = tf.keras.layers.Dense(d_model)
        self.wv = tf.keras.layers.Dense(d_model)

        self.dense = tf.keras.layers.Dense(d_model)

    def split_heads(self, x, batch_size):
        """Split the last dimension into (num_heads, depth).
        Transpose the result such that the shape is (batch_size, num_heads, seq_len, depth)
        """

        x = tf.reshape(x, (batch_size, -1, self.num_heads, self.depth))
        return tf.transpose(x, perm=[0, 2, 1, 3])

    def call(self, v, k, q, mask):
        batch_size = tf.shape(q)[0]

        q = self.wq(q)  # (batch_size, seq_len, d_model)
        k = self.wk(k)  # (batch_size, seq_len, d_model)
        v = self.wv(v)  # (batch_size, seq_len, d_model)

        q = self.split_heads(q, batch_size)  # (batch_size, num_heads, seq_len_q, depth)
        k = self.split_heads(k, batch_size)  # (batch_size, num_heads, seq_len_k, depth)
        v = self.split_heads(v, batch_size)  # (batch_size, num_heads, seq_len_v, depth)

        # scaled_attention.shape == (batch_size, num_heads, seq_len_q, depth)
        # attention_weights.shape == (batch_size, num_heads, seq_len_q, seq_len_k)
        scaled_attention, attention_weights = scaled_dot_product_attention(q, k, v, mask)

        scaled_attention = tf.transpose(scaled_attention, perm=[0, 2, 1, 3])  # (batch_size, seq_len_q, num_heads, depth)
        concat_attention = tf.reshape(scaled_attention, (batch_size, -1, self.d_model))  # (batch_size, seq_len_q, d_model)

        output = self.dense(concat_attention)  # (batch_size, seq_len_q, d_model) # a linear layer

        return output, attention_weights

# point-wise feed-forward NN (after multihead attention)
def point_wise_feed_forward_network(d_model, dff):
    return tf.keras.Sequential([
    tf.keras.layers.Dense(dff, activation='relu'),  # (batch_size, seq_len, dff)
    tf.keras.layers.Dense(d_model)  # (batch_size, seq_len, d_model)
    ])

# overall Transformer encoder with add+norm, added to both Multi-head atten and point-wise ffn
class EncoderLayer(tf.keras.layers.Layer):
    def __init__(self, *, d_model, num_heads, dff, rate=0.1):
        super(EncoderLayer, self).__init__()

        self.mha = MultiHeadAttention(d_model=d_model, num_heads=num_heads)
        self.ffn = point_wise_feed_forward_network(d_model, dff)

        self.layernorm1 = tf.keras.layers.LayerNormalization(epsilon=1e-6)
        self.layernorm2 = tf.keras.layers.LayerNormalization(epsilon=1e-6)

        self.dropout1 = tf.keras.layers.Dropout(rate, seed=123)
        self.dropout2 = tf.keras.layers.Dropout(rate, seed=123)

    def call(self, x, training, mask):
        attn_output, _ = self.mha(x, x, x, mask)  # (batch_size, input_seq_len, d_model)
        attn_output = self.dropout1(attn_output, training=training)
        out1 = self.layernorm1(x + attn_output)  # (batch_size, input_seq_len, d_model)

        ffn_output = self.ffn(out1)  # (batch_size, input_seq_len, d_model)
        ffn_output = self.dropout2(ffn_output, training=training)
        out2 = self.layernorm2(out1 + ffn_output)  # (batch_size, input_seq_len, d_model)

        return out2


class Encoder(tf.keras.layers.Layer):
    def __init__(self,*, num_layers=6, max_sequence=128, d_model=512, num_heads=8, dff=2048, input_vocab_size=1024,
    freeze_token_embeddings=False, token_embedding_matrix=None, rate=0.1):
        super(Encoder, self).__init__()

        self.d_model = d_model
        self.num_layers = num_layers

        if token_embedding_matrix is None:
            self.embedding = tf.keras.layers.Embedding(input_vocab_size, d_model)
        else:
            self.embedding = tf.keras.layers.Embedding(input_vocab_size, d_model,
            embeddings_initializer=tf.keras.initializers.Constant(token_embedding_matrix), trainable = (not freeze_token_embeddings))

        self.pos_encoding = positional_encoding(max_sequence, self.d_model)

        self.enc_layers = [EncoderLayer(d_model=d_model, num_heads=num_heads, dff=dff, rate=rate) for _ in range(num_layers)]

        self.dropout = tf.keras.layers.Dropout(rate, seed=123)

    def call(self, x, training, mask):
        seq_len = tf.shape(x)[1]

        # adding embedding and position encoding.
        x = self.embedding(x)  # (batch_size, input_seq_len, d_model)
        x *= tf.math.sqrt(tf.cast(self.d_model, tf.float32))
        x += self.pos_encoding[:, :seq_len, :]

        x = self.dropout(x, training=training)

        for i in range(self.num_layers):
            x = self.enc_layers[i](x, training, mask)

        return x  # (batch_size, input_seq_len, d_model)


class Transformer(tf.keras.layers.Layer):
    def __init__(self,*, num_layers=6, max_sequence=128, d_model=512, num_heads=8, dff=2048, input_vocab_size=1024,
    freeze_token_embeddings=False, token_embedding_matrix=None, rate=0.1):
        super(Transformer, self).__init__()
        self.max_sequence=max_sequence
        self.encoder = Encoder(num_layers=num_layers, max_sequence=max_sequence, d_model=d_model,
                               num_heads=num_heads, dff=dff,
                               rate=rate, input_vocab_size=input_vocab_size,
                               freeze_token_embeddings=freeze_token_embeddings,
                               token_embedding_matrix= token_embedding_matrix)

    def call(self, inputs, training=True):
        inp = inputs
        inp = inp[:, :self.max_sequence] # added by yp
        padding_mask = self.create_masks(inp)
        enc_output = self.encoder(inp, training, padding_mask)  # (batch_size, inp_seq_len, d_model)

        return enc_output # here None is just a placeholder to match output from pre-trained Transformer

    def create_masks(self, inp):
        padding_mask = create_padding_mask(inp)
        return padding_mask

class CRF_layer(tf.keras.layers.Layer):
    def __init__(self, number_of_classes):
        super(CRF_layer, self).__init__()
        self.number_of_classes = number_of_classes
        initializer = tf.keras.initializers.GlorotUniform()
        self.transition_parameters = tf.Variable(initializer([number_of_classes+2, number_of_classes+2]), 'transitions')
        # self.transition_parameters=tf.get_variable( "transitions",
        # shape=[number_of_classes+2, number_of_classes+2],initializer=initializer)
        # self.sess = sess
        # sess.run(self.transition_parameters.initializer)
        # self.transition_parameters = tf.identify(self.transition_parameters)
        # utils_tf.variable_summaries(self.transition_parameters)

    def call(self, unary_scores, input_label_indices_flat, training=True):
        # unary_scores: size = (seq_len, #class) >> (batch_size, max_seq_len, #class)
        # input_label_indices_flat: size = (seq_len) >> (batch_size>1, max_seq_len)

        # if training:
        #     tf.config.run_functions_eagerly(True)
        # else:
        #     tf.config.run_functions_eagerly(False)


        small_score = -1000.0
        large_score = 0.0
        batch_size, max_sequence_length = tf.shape(unary_scores)[0], tf.shape(unary_scores)[1]
        sequence_length_mask = tf.cast(input_label_indices_flat > -1, tf.int32) # (batch_size, max_seq_len)
        not_sequence_length_mask = tf.cast(input_label_indices_flat == -1, tf.int32) # (batch_size, max_seq_len)
        valid_sequence_lengths = tf.reduce_sum(tf.cast(input_label_indices_flat>-1, tf.int32), 1) # (batch_size)

        start_unary_scores = [[small_score] * self.number_of_classes + [large_score, small_score]] # (1, #class+2)
        start_unary_scores = tf.expand_dims(tf.constant(start_unary_scores), axis=1) # (1, 1, #class+2)
        end_unary_scores = [[small_score] * self.number_of_classes + [small_score, large_score]] # (1, #class+2)
        end_unary_scores = tf.expand_dims(tf.constant(end_unary_scores), axis=1) # (1, 1, #class+2)
        # unary_scores_with_start_and_end = tf.concat([tf.tile(tf.constant(small_score, shape=[1, 1,1]), [batch_size, max_sequence_length, 1]), unary_scores, tf.tile(tf.constant(small_score, shape=[1, 1, 1]) , [batch_size, max_sequence_length, 1])], 2) # (batch_size, max_seq_len, #class+2)
        unary_scores_with_start_and_end = tf.concat([unary_scores, tf.tile(tf.constant(small_score, shape=[1, 1, 2]) , [batch_size, max_sequence_length, 1])], 2) # (batch_size, max_seq_len, #class+2)
        # step 1: modify unary_scores_with_start_and_end to be (original values for valid lengths, 0 for unvalid length)
        unary_scores_with_start_and_end *= tf.cast(tf.expand_dims(sequence_length_mask, axis=-1), tf.float32) # (batch_size, max_seq_len, #class+2) with seq of not valid length as 0
        # step 2: create a mask to have same size with unary_scores_with_start_and_end but [0 for valid length, end_unary_scores for unvalid length]
        end_unary_scores_mask = tf.tile(end_unary_scores, [batch_size, max_sequence_length, 1]) # (batch_size, max_seq_len, #class+2)
        end_unary_scores_mask *= tf.cast(tf.expand_dims(not_sequence_length_mask, axis=-1), tf.float32) # (batch_size, max_seq_len, #class+2)
        # step 3: sum up mask and unary_scores_with_start_and_end
        unary_scores_with_start_and_end += end_unary_scores_mask # (batch_size, max_seq_len, #class+2)
        # step 4: insert start_unary_scores and end_unary_scores
        unary_scores_expanded = tf.concat([tf.tile(tf.constant(start_unary_scores), [batch_size, 1, 1]), unary_scores_with_start_and_end, tf.tile(tf.constant(end_unary_scores), [batch_size, 1, 1])], 1) # (batch_size, seq_len+2, #class+2)

        start_index, end_index = self.number_of_classes, self.number_of_classes + 1
        # transform input_label_indices_flat
        # step 1: change all seq with not valid length as 0
        input_label_indices_flat_batch = input_label_indices_flat * sequence_length_mask # (batch_size, max_seq_len)
        # step 2: creat mask for end_idx
        end_index_mask = tf.constant(end_index, shape=[batch_size, max_sequence_length]) # (batch_size, max_seq_len)
        end_index_mask *= not_sequence_length_mask # (batch_size, max_seq_len)
        # step 3: sum up mask and labels
        input_label_indices_flat_batch += end_index_mask # (batch_size, max_seq_len)
        # step 4: insert start_index and end_index
        input_label_indices_flat_expanded =  tf.concat([tf.constant(start_index, shape=[batch_size, 1]), input_label_indices_flat_batch, tf.constant(end_index, shape=[batch_size, 1])], 1) # (batch_size, max_seq_len+2)

        sequence_lengths_expanded = tf.add(valid_sequence_lengths, tf.constant(2, shape=[batch_size])) # (batch_size)

        # print('unary_scores_expanded is {} with shape {}'.format(unary_scores_expanded, unary_scores_expanded.shape))
        # print('input_label_indices_flat_expanded is {} with shape {}'.format(input_label_indices_flat_expanded, input_label_indices_flat_expanded.shape))
        # print('sequence_lengths_expanded is {} with shape {}'.format(sequence_lengths_expanded, sequence_lengths_expanded.shape))

        log_likelihood, _ = tfa.text.crf.crf_log_likelihood(unary_scores_expanded, input_label_indices_flat_expanded, sequence_lengths_expanded, transition_params=self.transition_parameters) # TF2


        # unary_scores_expanded, input_label_indices_flat_batch = [], []
        # # bs = int(self.sess.run(batch_size)) # TF1
        # bs = int(batch_size.numpy()) # TF2
        # msl = int(max_sequence_length.numpy())
        # for b in range(bs):
        #     # valid_len = int(self.sess.run(valid_sequence_lengths[b])) # TF1
        #     valid_len = int(valid_sequence_lengths[b].numpy())
        #
        #     # scores = self.sess.run(unary_scores_with_start_and_end[b]) # TF1: (max_seq_len, #class+2)
        #     scores = unary_scores_with_start_and_end[b].numpy().tolist() # (max_seq_len, #class+2)
        #     # scores_expanded = tf.concat([tf.constant(start_unary_scores), scores[:valid_len], tf.constant(end_unary_scores*(max_sequence_length-valid_len+1))], 0) # ?
        #     scores_expanded = start_unary_scores + scores[:valid_len] + end_unary_scores*(msl-valid_len+1) # (max_seq_len+2, #class+2)
        #     # scores_expanded = tf.concat([start_unary_scores, scores[:valid_len], end_unary_scores*(max_sequence_length-valid_len+1)], 0) # (max_seq_len+2, #class+2)
        #     unary_scores_expanded.append(scores_expanded)
        #
        #     # label_indices = self.sess.run(input_label_indices_flat[b]) # TF1: (max_seq_len)
        #     label_indices = input_label_indices_flat[b].numpy().tolist()
        #     labels_indices_expanded = [start_index] + label_indices[:valid_len] + [end_index] * (msl-valid_len+1) # (max_seq_len+2)
        #     input_label_indices_flat_batch.append(labels_indices_expanded)
        #
        # unary_scores_expanded = tf.constant(unary_scores_expanded)
        # input_label_indices_flat_batch = tf.constant(input_label_indices_flat_batch)
        #
        # sequence_lengths = tf.add(valid_sequence_lengths, tf.constant(2, shape=[batch_size])) # (batch_size)
        #
        # print('unary_scores_expanded is {} with shape {}'.format(unary_scores_expanded, unary_scores_expanded.shape))
        # print('input_label_indices_flat_batch is {} with shape {}'.format(input_label_indices_flat_batch, input_label_indices_flat_batch.shape))
        # print('sequence_lengths is {} with shape {}'.format(sequence_lengths, sequence_lengths.shape))
        #
        # # log_likelihood, _ = tf.contrib.crf.crf_log_likelihood(unary_scores_expanded, input_label_indices_flat_batch, sequence_lengths, transition_params=self.transition_parameters) # TF1
        # log_likelihood, _ = tfa.text.crf.crf_log_likelihood(unary_scores_expanded, input_label_indices_flat_batch, sequence_lengths, transition_params=self.transition_parameters) # TF2

        return unary_scores_expanded, log_likelihood


class EntityTransformer(tf.keras.Model):
    """
    An LSTM/Transformer architecture for named entity recognition.
    Uses a character embedding layer followed by an LSTM to generate vector representation from characters for each token.
    Then the character vector is concatenated with token embedding vector, which is input to another LSTM  followed by a CRF layer.
    """

    def __init__(self, *, num_layers=6, max_sequence=128, d_model=512, num_heads=8, dff=2048, input_vocab_size=1024,
    freeze_token_embeddings=False, token_embedding_matrix=None,
    rate=0.1, pretrained_transformer_name=None, use_pretrained_transformer=False,use_crf=True, number_of_classes=10):
        super(EntityTransformer, self).__init__()

        self.max_sequence=max_sequence

        self.use_crf = use_crf
        self.use_pretrained_transformer = use_pretrained_transformer
        # TBD: load pre-trained BERT on medicine domain
        if self.use_pretrained_transformer:
            self.transformer = TFAutoModel.from_pretrained(pretrained_transformer_name, from_pt=True) # load pretrained transformer
        else:
            self.transformer = Transformer(num_layers=num_layers, max_sequence=max_sequence, d_model=d_model,
            num_heads=num_heads, dff=dff, rate=rate, input_vocab_size=input_vocab_size,
            freeze_token_embeddings=freeze_token_embeddings, token_embedding_matrix=token_embedding_matrix)

        # self.ff_after_transformer = tf.keras.layers.Dense(d_model, activation='tanh')
        # self.tanh_layer= tf.keras.activations.tanh()
        self.ff_before_crf = tf.keras.layers.Dense(number_of_classes)

        if use_crf:
            self.crf = CRF_layer(number_of_classes=number_of_classes)

        self.unary_scores = None
        self.predictions = None

        # self.saver = tf.train.Saver(max_to_keep=parameters['maximum_number_of_epochs'])  # defaults to saving all variables


    def call(self, inputs, input_label_indices_vector, input_label_indices_flat, valid_inputs_indices=None, training=False):
        # inputs: size = (batch_size=1, seq_len) >> (batch_size>1, max_bpe_seq_len)
        # input_label_indices_vector: size = (seq_len, #label) >> (batch_size>1, max_word_seq_len, #class)
        # input_label_indices_flat: size = (seq_len) >> (batch_size>1, max_word_seq_len)
        # valid_inputs_indices: size = (batch_size>1, max_word_seq_len) OPTIONAL

        # transformer part
        if self.use_pretrained_transformer:
            self.max_sequence = self.transformer.config.max_position_embeddings
            # TO MODIFY LENGTHS of INPUTS
            inputs = inputs[:, :self.max_sequence]

            # inputs_valid_length_mask = tf.cast(valid_inputs_indices < self.max_sequence, tf.int32)
            inputs_valid_length_mask = tf.cast(tf.logical_and(tf.greater(valid_inputs_indices, 0), tf.less(valid_inputs_indices, self.max_sequence)), tf.int32) # (batch_size, max_word_seq_len)
            max_valid_length = tf.reduce_max(tf.reduce_sum(inputs_valid_length_mask, 1)) # [1]
            input_label_indices_vector = input_label_indices_vector[:, :max_valid_length, :] # (batch_size, max_word_seq_len, #class)
            input_label_indices_flat = input_label_indices_flat[:, :max_valid_length] # (batch_size, max_word_seq_len)
            valid_inputs_indices = valid_inputs_indices[:, :max_valid_length] # (batch_size, max_word_seq_len)

            # print('inputs are {} with shape {}'.format(inputs, inputs.shape))
            # print('input_label_indices_vector are {} with shape {}'.format(input_label_indices_vector, input_label_indices_vector.shape))
            # print('input_label_indices_flat are {} with shape {}'.format(input_label_indices_flat, input_label_indices_flat.shape))
            # print('valid_inputs_indices are {} with shape {}'.format(valid_inputs_indices, valid_inputs_indices.shape))
        else:
            inputs = inputs[:, :self.max_sequence] # added by yp, might remove later
            input_label_indices_vector = input_label_indices_vector[:, :self.max_sequence, :] # added by yp, might remove later
            input_label_indices_flat = input_label_indices_flat[:, :self.max_sequence] # added by yp, might remove later

        inputs_mask = inputs > 0 # size: (batch_size, max_seq_len)
        # print('Input of model is {} with type {}'.format(inputs, type(inputs)))
        if self.use_pretrained_transformer:
            output_transformer = self.transformer(inputs, training=training)[0] # (batch_size, max_seq_len, d_model)
        else:
            output_transformer = self.transformer(inputs, training=training)
        tanh_output_transformer = tf.keras.activations.tanh(output_transformer) # (batch_size, max_seq_len, d_model)
        if self.use_pretrained_transformer:
            # select output from transformer based on word-level from bpe-level
            # tanh_output_transformer = self.gather_along_second_axis(tanh_output_transformer, valid_inputs_indices) # (batch_size, max_seq_len, #d_model)
            tanh_output_transformer = slice_3d_from_2d(tanh_output_transformer, valid_inputs_indices) # (batch_size, max_seq_len, #d_model)


        scores = self.ff_before_crf(tanh_output_transformer, training=training) # (batch_size, max_seq_len, #class)

        # crf part + calculate loss and accuracy
        if self.use_crf:
            # print('scores is {} with shape {}'.format(scores, scores.shape))
            # print('input_label_indices_flat is {} with shape {}'.format(input_label_indices_flat, input_label_indices_flat.shape))
            unary_scores, likelihood = self.crf(scores, input_label_indices_flat, training)
            self.unary_scores = unary_scores
            loss = tf.reduce_mean(-likelihood)
            accuracy = tf.constant(1)
        else:
            # scores to be multipled mask: TBD
            predictions = tf.argmax(scores, 1)
            self.predictions = predictions
            loss = tf.reduce_mean(tf.nn.softmax_cross_entropy_with_logits(logits=scores, labels=input_label_indices_vector))
            accuracy = tf.reduce_mean(tf.cast(tf.equal(predictions, tf.argmax(input_label_indices_vector, 1)), 'float'))

        return loss, accuracy

    # utils for tensor slicing: codes from https://stackoverflow.com/questions/43933882/tensorflow-slice-a-3d-tensor-with-list-of-indices-along-the-second-axis
    # def tile_repeat(self, n, repTime):
    #     '''
    #     create something like 111..122..2333..33 ..... n..nn
    #     one particular number appears repTime consecutively.
    #     This is for flattening the indices.
    #     '''
    #     idx = tf.range(n)
    #     idx = tf.reshape(idx, [-1, 1])    # Convert to a n x 1 matrix.
    #     idx = tf.tile(idx, [1, repTime])  # Create multiple columns, each column has one number repeats repTime
    #     y = tf.reshape(idx, [-1])
    #     return y
    #
    #
    # def gather_along_second_axis(self, x, idx):
    #     '''
    #     x has shape: [batch_size, sentence_length, word_dim]
    #     idx has shape: [batch_size, num_indices]
    #     Basically, in each batch, get words from sentence having index specified in idx
    #     However, since tensorflow does not fully support indexing,
    #     gather only work for the first axis. We have to reshape the input data, gather then reshape again
    #     '''
    #     reshapedIdx = tf.reshape(idx, [-1]) # [batch_size*num_indices]
    #     idx_flattened = self.tile_repeat(tf.shape(x)[0], tf.shape(idx)[1]) * tf.shape(x)[1] + reshapedIdx
    #     y = tf.gather(tf.reshape(x, [-1,tf.shape(x)[2]]),  # flatten input
    #                 idx_flattened)
    #     y = tf.reshape(y, [tf.shape(x)[0],tf.shape(idx)[1],tf.shape(x)[2]])
    #     return y

    # def restore_from_pretrained_model(self, parameters, dataset, sess, token_to_vector=None):
    #     pretraining_dataset = pickle.load(open(os.path.join(parameters['pretrained_model_folder'], 'dataset.pickle'), 'rb'))
    #     pretrained_model_checkpoint_filepath = os.path.join(parameters['pretrained_model_folder'], 'model.ckpt')
    #
    #     # Assert that the label sets are the same
    #     # Test set should have the same label set as the pretrained dataset
    #     assert pretraining_dataset.index_to_label == dataset.index_to_label
    #
    #     # If the token and character mappings are exactly the same
    #     if pretraining_dataset.index_to_token == dataset.index_to_token and pretraining_dataset.index_to_character == dataset.index_to_character:
    #         # Restore the pretrained model
    #         self.saver.restore(sess, pretrained_model_checkpoint_filepath) # Works only when the dimensions of tensor variables are matched.
    #
    #     # If the token and character mappings are different between the pretrained model and the current model
    #     else:
    #         print('Failed to restore saved trained model') # TBD
    #         # Resize the token and character embedding weights to match them with the pretrained model (required in order to restore the pretrained model)
    #         # utils_tf.resize_tensor_variable(sess, self.character_embedding_weights, [pretraining_dataset.alphabet_size, parameters['character_embedding_dimension']])
    #         # utils_tf.resize_tensor_variable(sess, self.token_embedding_weights, [pretraining_dataset.vocabulary_size, parameters['token_embedding_dimension']])
    #
    #         # Restore the pretrained model
    #         # self.saver.restore(sess, pretrained_model_checkpoint_filepath) # Works only when the dimensions of tensor variables are matched.
    #
    #         # Get pretrained embeddings
    #         # character_embedding_weights, token_embedding_weights = sess.run([self.character_embedding_weights, self.token_embedding_weights])
    #
    #         # Restore the sizes of token and character embedding weights
    #         # utils_tf.resize_tensor_variable(sess, self.character_embedding_weights, [dataset.alphabet_size, parameters['character_embedding_dimension']])
    #         # utils_tf.resize_tensor_variable(sess, self.token_embedding_weights, [dataset.vocabulary_size, parameters['token_embedding_dimension']])
    #
    #         # Re-initialize the token and character embedding weights
    #         # sess.run(tf.variables_initializer([self.character_embedding_weights, self.token_embedding_weights]))
    #
    #         # Load embedding weights from pretrained token embeddings first
    #         # self.load_pretrained_token_embeddings(sess, dataset, parameters, token_to_vector=token_to_vector)
    #
    #         # Load embedding weights from pretrained model
    #         # self.load_embeddings_from_pretrained_model(sess, dataset, pretraining_dataset, token_embedding_weights, embedding_type='token')
    #         # self.load_embeddings_from_pretrained_model(sess, dataset, pretraining_dataset, character_embedding_weights, embedding_type='character')
    #
    #         # del pretraining_dataset
    #         # del character_embedding_weights
    #         # del token_embedding_weights
    #
    #     # Get transition parameters
    #     transition_params_trained = sess.run(self.crf.transition_parameters)
    #
    #     # if not parameters['reload_character_embeddings']:
    #     #     sess.run(tf.variables_initializer([self.character_embedding_weights]))
    #     # if not parameters['reload_character_lstm']:
    #     #     sess.run(tf.variables_initializer(self.character_lstm_variables))
    #     # if not parameters['reload_token_embeddings']:
    #     #     sess.run(tf.variables_initializer([self.token_embedding_weights]))
    #     #? we remove this line at the moment, assuming it is a list of stored trainable variables for lstm?
    #     # if not parameters['reload_token_lstm']:
    #     #     sess.run(tf.variables_initializer(self.token_lstm_variables))
    #     # if not parameters['reload_feedforward']:
    #     #     sess.run(tf.variables_initializer(self.feedforward_variables))
    #     # if not parameters['reload_crf']:
    #     #     sess.run(tf.variables_initializer(self.crf_variables))
    #
    #     return transition_params_trained
