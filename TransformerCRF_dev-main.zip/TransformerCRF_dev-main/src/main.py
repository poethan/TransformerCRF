'''
Statring file to run Transformer+CRF model
TO run:
CUDA_VISIBLE_DEVICES=1 python main.py
'''
# python main.py --parameters_filepath 'parameters.ini'
from __future__ import print_function
import os, sys, argparse
from argparse import RawTextHelpFormatter
from neuroner import NeuroNER

import warnings
warnings.filterwarnings('ignore')

def parse_arguments(arguments=None):
    ''' Parse the NeuroNER arguments

    arguments:
        arguments the arguments, optionally given as argument
    '''
    parser = argparse.ArgumentParser(description='''NeuroNER CLI''', formatter_class=RawTextHelpFormatter)
    parser.add_argument('--parameters_filepath', required=True, default=os.path.join('.','parameters.ini'), help='Specify the parameters file')

    # # argument_default_value = 'argument_default_dummy_value_please_ignore_d41d8cd98f00b204e9800998ecf8427e'
    # parser.add_argument('--dataset_text_folder', required=False, default='data', help='')
    # parser.add_argument('--output_folder', required=False, default='output', help='')
    # parser.add_argument('--use_pretrained_transformer', required=False, default=False, help='')
    # parser.add_argument('--train_model', required=False, default=True, help='')
    # parser.add_argument('--pretrained_model_folder', required=False, default=None, help='')
    #
    # parser.add_argument('--split_discontinuous', required=False, default=False, help='')
    # parser.add_argument('--check_for_lowercase', required=False, default=True, help='')
    #
    # parser.add_argument('--token_pretrained_embedding_filepath', required=False, default=None, help='')
    # parser.add_argument('--load_only_pretrained_token_embeddings', required=False, default=False, help='')
    # parser.add_argument('--load_all_pretrained_token_embeddings', required=False, default=False, help='')
    # parser.add_argument('--check_for_digits_replaced_with_zeros', required=False, default=True, help='')
    # parser.add_argument('--remap_unknown_tokens_to_unk', required=False, default=True, help='')
    #
    # parser.add_argument('--tokenizer', required=False, default=None, help='')
    # parser.add_argument('--spacylanguage', required=False, default=None, help='')
    # parser.add_argument('--tagging_format', required=False, default=None, help='')
    # # parser.add_argument('--use_character', required=False, default=False, help='')
    # parser.add_argument('--use_crf', required=False, default=True, help='')
    #
    # parser.add_argument('--token_embedding_dimension', required=False, default=768, help='')
    # # parser.add_argument('--character_embedding_dimension', required=False, default=768, help='')
    # # parser.add_argument('--freeze_token_embeddings', required=False, default=False, help='')
    # # parser.add_argument('--transformer_d_model', required=False, default=768, help='')
    # parser.add_argument('--dropout_rate', required=False, default=0.1, help='')
    # parser.add_argument('--gradient_clipping_value', required=False, default=0.1, help='')
    # parser.add_argument('--learning_rate', required=False, default=0.01, help='')
    # parser.add_argument('--optimizer', required=False, default='adam', help='')
    #
    # parser.add_argument('--maximum_number_of_epochs', required=False, default=100, help='')
    # parser.add_argument('--number_of_cpu_threads', required=False, default=8, help='')
    # parser.add_argument('--number_of_gpus', required=False, default=1, help='')
    # parser.add_argument('--patience', required=False, default=10, help='')
    # parser.add_argument('--main_evaluation_mode', required=False, default=None, help='')
    #
    # parser.add_argument('--plot_format', required=False, default=None, help='')
    # parser.add_argument('--verbose', required=False, default=False, help='')


    try:
        arguments = parser.parse_args(args=arguments)
    except:
        parser.print_help()
        sys.exit(0)

    arguments = vars(arguments)
    return arguments

def main(argv=sys.argv):
    ''' NeuroNER main method

    Args:
        parameters_filepath the path to the parameters file
        output_folder the path to the output folder
    '''
    # Parse arguments
    arguments = parse_arguments(argv[1:])

    nn = NeuroNER(arguments['parameters_filepath']) # need to change: only pass params path
    nn.fit()
    # nn.close()


if __name__ == "__main__":
    main()
